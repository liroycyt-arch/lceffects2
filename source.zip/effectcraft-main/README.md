# LiroycEffects

תוכנת גרפיקת תנועה ואפקטים חזותיים בעברית.

* ממשק מלא בעברית, סגנון גרדיאנט תכלת · כחול · סגול · ורוד.
* פורמט פרויקט: `.lcproj` · הגדרות מוכנות: `.lcpreset` · תבניות: `.lctemplate`.
* פונט ראשי: Rubik (גיבוי: Heebo, Assistant). את תיקיית `fonts` יש לשמור ליד קובץ ההרצה.

בנייה: `cargo build --release -p effectcraft`
