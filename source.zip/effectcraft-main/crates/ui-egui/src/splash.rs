//! The LiroycEffects start-up splash: the logo grows out of a violet glow over a dark gradient,
//! the name fades in and a brand-colour bar fills before the whole screen melts away.
//!
//! Only the real program turns it on ([`enable`], called from `main`), so tests and the control
//! protocol never wait behind it.

use std::sync::atomic::{AtomicBool, Ordering};

use egui::{Align2, Color32, Id, Order, Rect, Sense, pos2, vec2};

use crate::theme::{BRAND, Tokens};

static ENABLED: AtomicBool = AtomicBool::new(false);

/// Total length of the splash in seconds (the last [`FADE`] seconds fade out).
const DURATION: f64 = 3.0;
const FADE: f64 = 0.7;

/// Turn the splash on for this process.
pub fn enable() {
    ENABLED.store(true, Ordering::Relaxed);
}

fn ease_out(t: f32) -> f32 {
    1.0 - (1.0 - t.clamp(0.0, 1.0)).powi(3)
}

/// Paint the splash over everything for the first seconds of the program.
pub(crate) fn paint(ctx: &egui::Context) {
    if !ENABLED.load(Ordering::Relaxed) {
        return;
    }
    let now = ctx.input(|i| i.time);
    let start = ctx.data_mut(|d| *d.get_temp_mut_or_insert_with(Id::new("liroyc-splash-start"), || now));
    let t = now - start;
    if t >= DURATION {
        return;
    }
    ctx.request_repaint();
    let alpha = if t > DURATION - FADE { ((DURATION - t) / FADE) as f32 } else { 1.0 };
    let screen = ctx.content_rect();
    egui::Area::new(Id::new("liroyc-splash"))
        .order(Order::Tooltip)
        .fixed_pos(screen.min)
        .interactable(true)
        .show(ctx, |ui| {
            ui.set_opacity(alpha);
            let (rect, _) = ui.allocate_exact_size(screen.size(), Sense::click_and_drag());
            let p = ui.painter().clone();
            let secs = t as f32;
            p.rect_filled(rect, 0.0, Color32::from_rgb(0x07, 0x05, 0x12));

            // Slow drifting colour glows (cyan, blue, purple, pink) behind the logo.
            let c = rect.center();
            let r = rect.size().min_elem();
            for (i, col) in BRAND.iter().enumerate() {
                let a = secs * 0.55 + i as f32 * std::f32::consts::FRAC_PI_2;
                let pos = c + vec2(a.cos() * r * 0.28, a.sin() * r * 0.18);
                for k in (1..=7).rev() {
                    let f = k as f32 / 7.0;
                    p.circle_filled(pos, r * (0.10 + 0.30 * f), Color32::from_rgba_unmultiplied(col.r(), col.g(), col.b(), (7.0 * (1.0 - f) + 2.0) as u8));
                }
            }

            // The logo scales in with a soft overshoot.
            let grow = ease_out(secs / 0.9);
            let size = 150.0 * (0.55 + 0.45 * grow);
            let logo = Rect::from_center_size(c - vec2(0.0, 36.0), vec2(size, size));
            crate::header::paint_logo(&p, logo);

            // Name and tagline fade in one after the other.
            let name_a = ease_out((secs - 0.5) / 0.7);
            let name = Color32::from_rgba_unmultiplied(255, 255, 255, (255.0 * name_a) as u8);
            p.text(c + vec2(0.0, 92.0), Align2::CENTER_CENTER, "LiroycEffects", Tokens::semibold(34.0), name);
            let tag_a = ease_out((secs - 0.9) / 0.7);
            let tag = Color32::from_rgba_unmultiplied(0xb8, 0xaa, 0xf0, (255.0 * tag_a) as u8);
            p.text(c + vec2(0.0, 128.0), Align2::CENTER_CENTER, crate::i18n::he::visual("גרפיקת תנועה ואפקטים חזותיים"), Tokens::ui(15.0), tag);

            // A progress bar that fills with the brand gradient.
            let bar_w = 260.0;
            let bar = Rect::from_center_size(c + vec2(0.0, 176.0), vec2(bar_w, 4.0));
            p.rect_filled(bar, 2.0, Color32::from_white_alpha(22));
            let fill = ease_out(secs / (DURATION as f32 - 0.5));
            crate::theme::brand_gradient_alpha(&p, Rect::from_min_max(bar.min, pos2(bar.min.x + bar_w * fill, bar.max.y)), 255);
        });
}
